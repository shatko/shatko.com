<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<style type="text/css">
	#rate_button{
		text-align: center;
		padding:8% 5% 8% 5%;
		background:#FFA635;font-size:22px;border:none;color:#fff; border-bottom:8px solid #E08A1C;
		text-decoration: none;
		border-radius: 3px;
	}
	#rate_button:hover{
		background: #FF9918;

	}
	#rate_button:active{
		border: none;
		padding-top: 9%;
	}
	#rate_buttons:active{
		border: none;
		padding-top: 9%;
	}

</style>
<li>
	 Unlock All Layouts.
</li>
<li>
	Customizable Design.
</li>
<li>
	Google Fonts.
</li>
<li>
	Facebook Integration.
</li>
<li>
	Twitter Integration.
</li>
<li>
	Instagram Integration.
</li>
<li>
	Fast Support.
</li>
<li>
	Unlimited Updates.
</li>
<br>
<a style='text-decoration: none;' href="http://web-settler.com/wordpress-facebook-feed/" target='_blank'><div id='rate_button' style=''>Get Premium Version</div></a>